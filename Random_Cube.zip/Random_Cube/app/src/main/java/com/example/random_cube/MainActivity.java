package com.example.random_cube;

import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private int suma, increment;
    private float srednia;
    private final ArrayList<Integer> historia = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState != null) {
            suma = savedInstanceState.getInt("suma", 0);
            increment = savedInstanceState.getInt("increment", 0);
            historia.addAll(savedInstanceState.getIntegerArrayList("historia"));
        }
        TextView sumView = findViewById(R.id.numberText);
        sumView.setText("LOSOWANIE");
        new Handler().postDelayed(this::roll, 1000);
    }

    private void roll() {
        Random rand = new Random();
        int liczba = rand.nextInt(6) + 1;

        suma += liczba;
        increment++;
        srednia = (float) suma / increment;
        historia.add(liczba);

        TextView sumView = findViewById(R.id.numberText);
        sumView.setText(String.valueOf(suma));

        TextView avgView = findViewById(R.id.averageText);
        avgView.setText("Średnia: " + srednia);

        TextView histView = findViewById(R.id.historyText);
        histView.setText("Historia: " + formatHistoria());
    }

    private String formatHistoria() {
        if (historia.isEmpty()) return "";
        String wynik = "";
        for (int i = 0; i < historia.size(); i++) {
            wynik += historia.get(i);
            if (i < historia.size() - 1) wynik += ",";
        }
        return wynik;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("suma", suma);
        outState.putInt("increment", increment);
        outState.putIntegerArrayList("historia", historia);
    }
}