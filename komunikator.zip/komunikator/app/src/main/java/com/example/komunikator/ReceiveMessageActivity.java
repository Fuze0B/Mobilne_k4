package com.example.komunikator;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class ReceiveMessageActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "message";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_message);


        TextView textView = findViewById(R.id.message);
        Intent intent = getIntent();
        String message = intent.getStringExtra("message");
        if (message != null) {
            textView.setText(message);
        } else {
            textView.setText("No message received");
        }
        }
    }