package com.example.cv;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ImageView ivPhotoTop;
    private ImageView ivPhotoBottom;
    private EditText etImie, etNazwisko, etEmail, etTelefon;
    private RadioGroup rgPlec;
    private CheckBox cbZgoda;
    private Switch switchOferty;
    private TextView tvPodsumowanie;
    private Uri zdjecieUri;

    private final ActivityResultLauncher<String> launcher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) {
                    zdjecieUri = uri;
                    ivPhotoTop.setImageURI(uri);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivPhotoTop = findViewById(R.id.ivPhotoTop);
        ivPhotoBottom = findViewById(R.id.ivPhotoBottom);
        etImie = findViewById(R.id.etImie);
        etNazwisko = findViewById(R.id.etNazwisko);
        etEmail = findViewById(R.id.etEmail);
        etTelefon = findViewById(R.id.etTelefon);
        rgPlec = findViewById(R.id.rgPlec);
        cbZgoda = findViewById(R.id.cbZgoda);
        switchOferty = findViewById(R.id.switchOferty);
        tvPodsumowanie = findViewById(R.id.tvPodsumowanie);
    }

    public void wybierzZdjecie(View v) {
        launcher.launch("image/*");
    }

    public void zapisz(View v) {
        String imie = etImie.getText().toString().trim();
        String nazwisko = etNazwisko.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String telefon = etTelefon.getText().toString().trim();

        String plec = "nie wybrano";
        int id = rgPlec.getCheckedRadioButtonId();
        if (id == R.id.rbKobieta)    plec = "Kobieta";
        else if (id == R.id.rbMezczyzna)  plec = "Mężczyzna";
        else {
            plec = "Nie Podano";}

            String tekst = "Imię: " + imie + "\n" +
                    "Nazwisko: " + nazwisko + "\n" +
                    "Email: " + email + "\n" +
                    "Telefon: " + telefon + "\n" +
                    "Płeć: " + plec + "\n" +
                    "Zgoda: " + (cbZgoda.isChecked() ? "Tak" : "Nie") + "\n" +
                    "Oferty: " + (switchOferty.isChecked() ? "Tak" : "Nie");

            if (zdjecieUri != null) {
                tekst += "\nZdjęcie: dodane";
                ivPhotoBottom.setImageURI(zdjecieUri);
                ivPhotoBottom.setVisibility(View.VISIBLE);
            } else {
                ivPhotoBottom.setVisibility(View.GONE);
            }

            tvPodsumowanie.setText(tekst);
            tvPodsumowanie.setVisibility(View.VISIBLE);
        }
}