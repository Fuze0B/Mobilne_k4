package com.example.coffeina;

public class Location {
    private String town;
    private String street;
    private int imageResourceId;

    public static final Location[] locations = {
            new Location("Warszawa", "ul. Marszałkowska 10", R.drawable.warszawa),
            new Location("Kraków", "ul. Floriańska 5", R.drawable.krakow),
            new Location("Gdańsk", "ul. Długa 12", R.drawable.gdansk)
    };

    private Location(String town, String street, int imageResourceId) {
        this.town = town;
        this.street = street;
        this.imageResourceId = imageResourceId;
    }

    public String getStreet() {
        return street;
    }

    public String getTown() {
        return town;
    }

    public int getImageResourceId() {
        return imageResourceId;
    }

    @Override
    public String toString() {
        return this.town;
    }
}
