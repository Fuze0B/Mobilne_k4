package com.example.coffeina;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LocationActivity extends AppCompatActivity {

    public static final String EXTRA_LOCATIONID = "locationid";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_location);

        int locationId = getIntent().getIntExtra(EXTRA_LOCATIONID, 0);
        Location location = Location.locations[locationId];
        TextView townView = (TextView) findViewById(R.id.town);
        townView.setText(location.getTown());
        TextView streetView = (TextView) findViewById(R.id.street);
        streetView.setText(location.getStreet());
        ImageView photo = (ImageView) findViewById(R.id.photo);
        photo.setImageResource(location.getImageResourceId());
        photo.setContentDescription(location.getTown());
    }
}