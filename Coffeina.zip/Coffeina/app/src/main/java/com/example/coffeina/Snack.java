package com.example.coffeina;

public class Snack {
    private String name;
    private String description;
    private int imageResourceId;

    public static final Snack[] snacks = {
            new Snack("Brownie", "Wilgotne ciasto czekoladowe z kawałkami czekolady.", R.drawable.brownie),
            new Snack("Sernik", "Kremowy sernik na chrupiącym spodzie, posypany cukrem pudrem.", R.drawable.sernik),
            new Snack("Ciasto marchewkowe", "Delikatne ciasto z marchewką, orzechami i przyprawami korzennymi.", R.drawable.marchewkowe)
    };

    private Snack(String name, String description, int imageResourceId) {
        this.name = name;
        this.description = description;
        this.imageResourceId = imageResourceId;
    }

    public String getDescription() {
        return description;
    }

    public String getName() {
        return name;
    }

    public int getImageResourceId() {
        return imageResourceId;
    }

    @Override
    public String toString() {
        return this.name;
    }
}
