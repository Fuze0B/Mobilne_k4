package com.example.coffeina;

import android.content.ContentValues;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
public class CoffeinaDatabaseHelper extends SQLiteOpenHelper {

    private final static String DB_NAME = "coffeina";
    private final static int DB_VERSION = 1;
    CoffeinaDatabaseHelper(Context context){
        super(context, DB_NAME,null, DB_VERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE DRINK(_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "NAME TEXT, "
                + "DESCRIPTION TEXT, "
                + "IMAGE_RESOURCE_ID INTEGER);");
        insertDrink(sqLiteDatabase,"Latte","Czarne espresso z gorącym mlekiem i mleczną pianką.", R.drawable.latte);
        insertDrink(sqLiteDatabase,"Cappuccino","Czarne espresso z dużą ilością spienionego mleka.", R.drawable.cappucino);
        insertDrink(sqLiteDatabase,"Espresso","Czarna kawa ze świeżo mielonych ziaren najwyższej jakości.", R.drawable.filter);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        updateMyDatabase(db, oldVersion, newVersion);
    }

    private void updateMyDatabase(SQLiteDatabase db, int oldVersion, int newVersion){
        if(oldVersion<1) {
            db.execSQL("CREATE TABLE DRINK(_id INTEGER PRIMARY KEY AUTOINCREMENT," + "NAME TEXT, " + "DESCRIPTION TEXT, " + "IMAGE_RESOURCE_ID INTEGER);");
            insertDrink(db, "Latte", "Czarne espresso z gorącym mlekiem i mleczną pianką.", R.drawable.latte);
            insertDrink(db, "Cappucino", "Czarne espresso z dużą ilością spienionego mleka.", R.drawable.cappucino);
            insertDrink(db, "Ekspresso", "Czarna kawa ze świeżo zmielonym ziarnem najzwyższej jakości.", R.drawable.filter);
        }
    }
    private static void insertDrink(SQLiteDatabase db,
                                        String name,
                                        String description,
                                        int resourceId) {
        ContentValues drinkvalues = new ContentValues();
        drinkvalues.put("NAME",name);
        drinkvalues.put("DESCRIPTION",description);
        drinkvalues.put("IMAGE_RESOURCE_ID",resourceId);
        db.insert("DRINK",null,drinkvalues);
    }
}
