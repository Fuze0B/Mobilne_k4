package com.example.coffeina;

import android.media.Image;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;



public class DrinkActivity extends AppCompatActivity {
    public static final String EXTRA_DRINKID = "drinkid";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_drink);

        int drinkId = (Integer)getIntent().getIntExtra(EXTRA_DRINKID, 0);
        Drink drink = Drink.drinks[drinkId];
        TextView name = (TextView) findViewById(R.id.name);
        name.setText(drink.getName());
        TextView description = (TextView) findViewById(R.id.description);
        description.setText(drink.getDescription());
        ImageView photo = (ImageView) findViewById(R.id.photo);
        photo.setImageResource(drink.getImageResourceId());
        photo.setContentDescription(drink.getName());

    }

}