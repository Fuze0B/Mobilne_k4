package com.example.coffeina;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.media.Image;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;



public class DrinkActivity extends AppCompatActivity {
    public static final String EXTRA_DRINKID = "drinkid";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_drink);

        int drinkId = (Integer)getIntent().getIntExtra(EXTRA_DRINKID, 0);

        try{
            SQLiteOpenHelper coffeinaDatabaseHelper = new CoffeinaDatabaseHelper(this);
            SQLiteDatabase db = coffeinaDatabaseHelper.getReadableDatabase();
            Cursor cursor = db.query("DRINK",
                                            new String[] {"NAME", "DESCRIPTION",
                                                                    "IMAGE_RESOURCE_ID"},
                    "_id = ?",
                    new String[] {Integer.toString(drinkId)},
                    null,null,null);
        if(cursor.moveToFirst()) {
            String nameText = cursor.getString(0);
            String descriptionText = cursor.getString(1);
            int photoId = cursor.getInt(2);
            TextView name  = (TextView)findViewById(R.id.name);
            name.setText(nameText);

            TextView description = (TextView) findViewById(R.id.description);
            description.setText(descriptionText);

            ImageView photo = (ImageView)findViewById(R.id.photo);
            photo.setImageResource(photoId);
            photo.setContentDescription(nameText);
        }
        cursor.close();
        db.close();
        } catch(SQLiteException e){
            Toast toast = Toast.makeText(this,"Baza danych jest niedostępna",
                    Toast.LENGTH_SHORT);
            toast.show();
        }

    }

}