package com.example.coffeina;

import android.content.ContentValues;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
public class CoffeinaDatabaseHelper extends SQLiteOpenHelper {

    private final static String DB_NAME = "coffeina";
    private final static int DB_VERSION = 1;
    CoffeinaDatabaseHelper(Context context){
        super(context, DB_NAME,null, DB_VERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE DRINK(_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "NAME TEXT, "
                + "DESCRIPTION TEXT, "
                + "IMAGE_RESOURCE_ID INTEGER);");
        insertDrink(sqLiteDatabase,"Latte","Czarne espresso z gorącym mlekiem i mleczną pianką.", R.drawable.latte);
        insertDrink(sqLiteDatabase,"Cappuccino","Czarne espresso z dużą ilością spienionego mleka.", R.drawable.cappucino);
        insertDrink(sqLiteDatabase,"Espresso","Czarna kawa ze świeżo mielonych ziaren najwyższej jakości.", R.drawable.filter);

        sqLiteDatabase.execSQL("CREATE TABLE SNACK(_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "NAME TEXT, "
                + "DESCRIPTION TEXT, "
                + "IMAGE_RESOURCE_ID INTEGER);");
        insertSnack(sqLiteDatabase,"Brownie","Wilgotne ciasto czekoladowe z kawałkami czekolady.", R.drawable.brownie);
        insertSnack(sqLiteDatabase,"Sernik","Kremowy sernik na chrupiącym spodzie, posypany cukrem pudrem.", R.drawable.sernik);
        insertSnack(sqLiteDatabase,"Ciasto marchewkowe","Delikatne ciasto z marchewką, orzechami i przyprawami korzennymi.", R.drawable.marchewkowe);

        sqLiteDatabase.execSQL("CREATE TABLE LOCATION(_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "TOWN TEXT, "
                + "STREET TEXT, "
                + "IMAGE_RESOURCE_ID INTEGER);");
        insertLocation(sqLiteDatabase,"Warszawa","ul. Marszałkowska 10", R.drawable.warszawa);
        insertLocation(sqLiteDatabase,"Kraków","ul. Floriańska 5", R.drawable.krakow);
        insertLocation(sqLiteDatabase,"Gdańsk","ul. Długa 12", R.drawable.gdansk);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        updateMyDatabase(db, oldVersion, newVersion);
    }

    private void updateMyDatabase(SQLiteDatabase db, int oldVersion, int newVersion){
        if(oldVersion<1) {
            db.execSQL("CREATE TABLE DRINK(_id INTEGER PRIMARY KEY AUTOINCREMENT," + "NAME TEXT, " + "DESCRIPTION TEXT, " + "IMAGE_RESOURCE_ID INTEGER);");
            insertDrink(db, "Latte", "Czarne espresso z gorącym mlekiem i mleczną pianką.", R.drawable.latte);
            insertDrink(db, "Cappucino", "Czarne espresso z dużą ilością spienionego mleka.", R.drawable.cappucino);
            insertDrink(db, "Ekspresso", "Czarna kawa ze świeżo zmielonym ziarnem najzwyższej jakości.", R.drawable.filter);
            db.execSQL("CREATE TABLE SNACK(_id INTEGER PRIMARY KEY AUTOINCREMENT, " + "NAME TEXT, " + "DESCRIPTION TEXT, " + "IMAGE_RESOURCE_ID INTEGER);");
            insertSnack(db,"Brownie","Wilgotne ciasto czekoladowe z kawałkami czekolady.", R.drawable.brownie);
            insertSnack(db,"Sernik","Kremowy sernik na chrupiącym spodzie, posypany cukrem pudrem.", R.drawable.sernik);
            insertSnack(db,"Ciasto marchewkowe","Delikatne ciasto z marchewką, orzechami i przyprawami korzennymi.", R.drawable.marchewkowe);

            db.execSQL("CREATE TABLE LOCATION(_id INTEGER PRIMARY KEY AUTOINCREMENT, " + "TOWN TEXT, " + "STREET TEXT, " + "IMAGE_RESOURCE_ID INTEGER);");
            insertLocation(db,"Warszawa","ul. Marszałkowska 10", R.drawable.warszawa);
            insertLocation(db,"Kraków","ul. Floriańska 5", R.drawable.krakow);
            insertLocation(db,"Gdańsk","ul. Długa 12", R.drawable.gdansk);
        }
    }
    private static void insertDrink(SQLiteDatabase db,
                                        String name,
                                        String description,
                                        int resourceId) {
        ContentValues drinkvalues = new ContentValues();
        drinkvalues.put("NAME",name);
        drinkvalues.put("DESCRIPTION",description);
        drinkvalues.put("IMAGE_RESOURCE_ID",resourceId);
        db.insert("DRINK",null,drinkvalues);
    }
    private static void insertSnack(SQLiteDatabase db,
                                    String name,
                                    String description,
                                    int resourceId) {
        ContentValues snackvalues = new ContentValues();
        snackvalues.put("NAME",name);
        snackvalues.put("DESCRIPTION",description);
        snackvalues.put("IMAGE_RESOURCE_ID",resourceId);
        db.insert("SNACK",null,snackvalues);
    }
    private static void insertLocation(SQLiteDatabase db,
                                    String town,
                                    String street,
                                    int resourceId) {
        ContentValues locationvalues = new ContentValues();
        locationvalues.put("TOWN",town);
        locationvalues.put("STREET",street);
        locationvalues.put("IMAGE_RESOURCE_ID",resourceId);
        db.insert("LOCATION",null,locationvalues);
    }


}
