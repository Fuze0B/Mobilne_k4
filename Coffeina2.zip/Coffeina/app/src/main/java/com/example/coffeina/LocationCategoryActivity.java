package com.example.coffeina;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class LocationCategoryActivity extends AppCompatActivity {
    private SQLiteDatabase db;
    private Cursor cursor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_location_category);

        ListView listLocations = (ListView) findViewById(R.id.list_locations);
        SQLiteOpenHelper coffeinaDatabaseHelper = new CoffeinaDatabaseHelper(this);
        try {
            db = coffeinaDatabaseHelper.getReadableDatabase();
            cursor = db.query("LOCATION",
                    new String[]{"_id", "TOWN"},
                    null, null, null, null, null);

            SimpleCursorAdapter listAdapter = new SimpleCursorAdapter(this,
                    android.R.layout.simple_list_item_1, cursor, new String[]{"TOWN"},
                    new int[]{android.R.id.text1},0);
            listLocations.setAdapter(listAdapter);
        } catch(SQLiteException e){
            Toast toast = Toast.makeText(this, "Baza danych jest niedostępna",
                    Toast.LENGTH_SHORT);
            toast.show();
        }

        AdapterView.OnItemClickListener itemClickListener =
                new AdapterView.OnItemClickListener() {
                    public void onItemClick(AdapterView<?> listLocations,
                                            View itemView,
                                            int position,
                                            long id) {
                        Intent intent = new Intent(LocationCategoryActivity.this,
                                LocationActivity.class);
                        intent.putExtra(LocationActivity.EXTRA_LOCATIONID, (int) id);
                        startActivity(intent);
                    }
            };
        listLocations.setOnItemClickListener(itemClickListener);
        }
    @Override
    public void onDestroy() {
        super.onDestroy();
        cursor.close();
        db.close();
    }

}