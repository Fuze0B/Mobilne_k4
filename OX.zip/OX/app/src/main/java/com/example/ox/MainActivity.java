package com.example.ox;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    private TextView[][] cells = new TextView[3][3];
    private int[][] bg = new int[3][3];
    private boolean player1Turn = true;
    private boolean endOfGame = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cells[0][0] = findViewById(R.id.cell00);
        cells[0][1] = findViewById(R.id.cell01);
        cells[0][2] = findViewById(R.id.cell02);
        cells[1][0] = findViewById(R.id.cell10);
        cells[1][1] = findViewById(R.id.cell11);
        cells[1][2] = findViewById(R.id.cell12);
        cells[2][0] = findViewById(R.id.cell20);
        cells[2][1] = findViewById(R.id.cell21);
        cells[2][2] = findViewById(R.id.cell22);

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                bg[i][j] = Color.WHITE;
                cells[i][j].setBackgroundColor(Color.WHITE);
            }
        }

        if (savedInstanceState != null) {
            cells[0][0].setText(savedInstanceState.getString("cell00", ""));
            cells[0][1].setText(savedInstanceState.getString("cell01", ""));
            cells[0][2].setText(savedInstanceState.getString("cell02", ""));
            cells[1][0].setText(savedInstanceState.getString("cell10", ""));
            cells[1][1].setText(savedInstanceState.getString("cell11", ""));
            cells[1][2].setText(savedInstanceState.getString("cell12", ""));
            cells[2][0].setText(savedInstanceState.getString("cell20", ""));
            cells[2][1].setText(savedInstanceState.getString("cell21", ""));
            cells[2][2].setText(savedInstanceState.getString("cell22", ""));

            cells[0][0].setBackgroundColor(savedInstanceState.getInt("bg00", Color.WHITE));
            cells[0][1].setBackgroundColor(savedInstanceState.getInt("bg01", Color.WHITE));
            cells[0][2].setBackgroundColor(savedInstanceState.getInt("bg02", Color.WHITE));
            cells[1][0].setBackgroundColor(savedInstanceState.getInt("bg10", Color.WHITE));
            cells[1][1].setBackgroundColor(savedInstanceState.getInt("bg11", Color.WHITE));
            cells[1][2].setBackgroundColor(savedInstanceState.getInt("bg12", Color.WHITE));
            cells[2][0].setBackgroundColor(savedInstanceState.getInt("bg20", Color.WHITE));
            cells[2][1].setBackgroundColor(savedInstanceState.getInt("bg21", Color.WHITE));
            cells[2][2].setBackgroundColor(savedInstanceState.getInt("bg22", Color.WHITE));

            bg[0][0] = savedInstanceState.getInt("bg00", Color.WHITE);
            bg[0][1] = savedInstanceState.getInt("bg01", Color.WHITE);
            bg[0][2] = savedInstanceState.getInt("bg02", Color.WHITE);
            bg[1][0] = savedInstanceState.getInt("bg10", Color.WHITE);
            bg[1][1] = savedInstanceState.getInt("bg11", Color.WHITE);
            bg[1][2] = savedInstanceState.getInt("bg12", Color.WHITE);
            bg[2][0] = savedInstanceState.getInt("bg20", Color.WHITE);
            bg[2][1] = savedInstanceState.getInt("bg21", Color.WHITE);
            bg[2][2] = savedInstanceState.getInt("bg22", Color.WHITE);

            player1Turn = savedInstanceState.getBoolean("player1Turn", true);
            endOfGame = savedInstanceState.getBoolean("endOfGame", false);
        }
    }

    public void onCellClick(View v) {
        if (endOfGame) {
            return;
        }
        TextView cell = (TextView) v;
        String currentText = cell.getText().toString();
        if (currentText.isEmpty()) {
            if (player1Turn) {
                cell.setText("X");
            } else {
                cell.setText("O");
            }
            if (changeColor()) {
            endOfGame=true;
            } else {
                player1Turn = !player1Turn;
            }
        }
    }

    private boolean changeColor() {
        for (int i = 0; i < 3; i++) {
            if (cells[i][0].getText().toString().equals(cells[i][1].getText().toString()) &&
                    cells[i][1].getText().toString().equals(cells[i][2].getText().toString()) &&
                    !cells[i][0].getText().toString().isEmpty()) {
                cells[i][0].setBackgroundColor(Color.MAGENTA);
                cells[i][1].setBackgroundColor(Color.MAGENTA);
                cells[i][2].setBackgroundColor(Color.MAGENTA);
                bg[i][0] = Color.MAGENTA;
                bg[i][1] = Color.MAGENTA;
                bg[i][2] = Color.MAGENTA;
                return true;
            }
        }

        for (int j = 0; j < 3; j++) {
            if (cells[0][j].getText().toString().equals(cells[1][j].getText().toString()) &&
                    cells[1][j].getText().toString().equals(cells[2][j].getText().toString()) &&
                    !cells[0][j].getText().toString().isEmpty()) {
                cells[0][j].setBackgroundColor(Color.MAGENTA);
                cells[1][j].setBackgroundColor(Color.MAGENTA);
                cells[2][j].setBackgroundColor(Color.MAGENTA);
                bg[0][j] = Color.MAGENTA;
                bg[1][j] = Color.MAGENTA;
                bg[2][j] = Color.MAGENTA;
                return true;
            }
        }

        if (cells[0][0].getText().toString().equals(cells[1][1].getText().toString()) &&
                cells[1][1].getText().toString().equals(cells[2][2].getText().toString()) &&
                !cells[0][0].getText().toString().isEmpty()) {
            cells[0][0].setBackgroundColor(Color.MAGENTA);
            cells[1][1].setBackgroundColor(Color.MAGENTA);
            cells[2][2].setBackgroundColor(Color.MAGENTA);
            bg[0][0] = Color.MAGENTA;
            bg[1][1] = Color.MAGENTA;
            bg[2][2] = Color.MAGENTA;
            return true;
        }
        if (cells[0][2].getText().toString().equals(cells[1][1].getText().toString()) &&
                cells[1][1].getText().toString().equals(cells[2][0].getText().toString()) &&
                !cells[0][2].getText().toString().isEmpty()) {
            cells[0][2].setBackgroundColor(Color.MAGENTA);
            cells[1][1].setBackgroundColor(Color.MAGENTA);
            cells[2][0].setBackgroundColor(Color.MAGENTA);
            bg[0][2] = Color.MAGENTA;
            bg[1][1] = Color.MAGENTA;
            bg[2][0] = Color.MAGENTA;
            return true;
        }

        return false;
    }

    public void resetGame(View v) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                cells[i][j].setText("");
                cells[i][j].setBackgroundColor(Color.WHITE);
                bg[i][j] = Color.WHITE;
            }
        }
        player1Turn = true;
        endOfGame = false;
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);

        savedInstanceState.putString("cell00", cells[0][0].getText().toString());
        savedInstanceState.putString("cell01", cells[0][1].getText().toString());
        savedInstanceState.putString("cell02", cells[0][2].getText().toString());
        savedInstanceState.putString("cell10", cells[1][0].getText().toString());
        savedInstanceState.putString("cell11", cells[1][1].getText().toString());
        savedInstanceState.putString("cell12", cells[1][2].getText().toString());
        savedInstanceState.putString("cell20", cells[2][0].getText().toString());
        savedInstanceState.putString("cell21", cells[2][1].getText().toString());
        savedInstanceState.putString("cell22", cells[2][2].getText().toString());

        savedInstanceState.putInt("bg00", bg[0][0]);
        savedInstanceState.putInt("bg01", bg[0][1]);
        savedInstanceState.putInt("bg02", bg[0][2]);
        savedInstanceState.putInt("bg10", bg[1][0]);
        savedInstanceState.putInt("bg11", bg[1][1]);
        savedInstanceState.putInt("bg12", bg[1][2]);
        savedInstanceState.putInt("bg20", bg[2][0]);
        savedInstanceState.putInt("bg21", bg[2][1]);
        savedInstanceState.putInt("bg22", bg[2][2]);

        savedInstanceState.putBoolean("player1Turn", player1Turn);
        savedInstanceState.putBoolean("endOfGame", endOfGame);
    }
}