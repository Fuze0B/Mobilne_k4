package com.example.ox;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView[][] cells = new TextView[3][3];
    private boolean player1Turn = true;  // true = X, false = O

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cells[0][0] = findViewById(R.id.cell00);
        cells[0][1] = findViewById(R.id.cell01);
        cells[0][2] = findViewById(R.id.cell02);
        cells[1][0] = findViewById(R.id.cell10);
        cells[1][1] = findViewById(R.id.cell11);
        cells[1][2] = findViewById(R.id.cell12);
        cells[2][0] = findViewById(R.id.cell20);
        cells[2][1] = findViewById(R.id.cell21);
        cells[2][2] = findViewById(R.id.cell22);
    }

    public void onCellClick(View v) {
        TextView cell = (TextView) v;
        String currentText = cell.getText().toString();
        if (currentText.isEmpty()) {
            if (player1Turn) {
                cell.setText("X");
            } else {
                cell.setText("O");
            }
            if (changeColor()) {
                String winner = player1Turn ? "X" : "O";
                Toast.makeText(this, "Gracz " + winner + " wygrał!", Toast.LENGTH_LONG).show();
            } else {
                player1Turn = !player1Turn;
            }
        }
    }

    private boolean changeColor() {
        for (int i = 0; i < 3; i++) {
            if (cells[i][0].getText().toString().equals(cells[i][1].getText().toString()) &&
                    cells[i][1].getText().toString().equals(cells[i][2].getText().toString()) &&
                    !cells[i][0].getText().toString().isEmpty()) {
                cells[i][0].setBackgroundColor(Color.BLUE);
                cells[i][1].setBackgroundColor(Color.BLUE);
                cells[i][2].setBackgroundColor(Color.BLUE);
                return true;
            }
        }

        for (int j = 0; j < 3; j++) {
            if (cells[0][j].getText().toString().equals(cells[1][j].getText().toString()) &&
                    cells[1][j].getText().toString().equals(cells[2][j].getText().toString()) &&
                    !cells[0][j].getText().toString().isEmpty()) {
                cells[0][j].setBackgroundColor(Color.BLUE);
                cells[1][j].setBackgroundColor(Color.BLUE);
                cells[2][j].setBackgroundColor(Color.BLUE);
                return true;
            }
        }

        if (cells[0][0].getText().toString().equals(cells[1][1].getText().toString()) &&
                cells[1][1].getText().toString().equals(cells[2][2].getText().toString()) &&
                !cells[0][0].getText().toString().isEmpty()) {
            cells[0][0].setBackgroundColor(Color.BLUE);
            cells[1][1].setBackgroundColor(Color.BLUE);
            cells[2][2].setBackgroundColor(Color.BLUE);
            return true;
        }
        if (cells[0][2].getText().toString().equals(cells[1][1].getText().toString()) &&
                cells[1][1].getText().toString().equals(cells[2][0].getText().toString()) &&
                !cells[0][2].getText().toString().isEmpty()) {
            cells[0][2].setBackgroundColor(Color.BLUE);
            cells[1][1].setBackgroundColor(Color.BLUE);
            cells[2][0].setBackgroundColor(Color.BLUE);
            return true;
        }

        return false;
    }

    public void resetGame(View v) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                cells[i][j].setText("");
                cells[i][j].setBackgroundColor(Color.WHITE);
            }
        }
        player1Turn = true;
    }
}