package com.example.cv;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

public class MainActivity extends AppCompatActivity {

    private ImageView ivPhotoTop;
    private EditText etImie, etNazwisko, etEmail, etTelefon;
    private RadioGroup rgPlec;
    private RadioButton women, men;
    private CheckBox cbZgoda;
    private SwitchCompat switchOferty;
    private SwitchCompat switchZablokuj;
    private Spinner spinnerWyksztalcenie;
    private TextView tvPodsumowanie;
    private Uri zdjecieUri;

    private final ActivityResultLauncher<String> launcher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) {
                    zdjecieUri = uri;
                    ivPhotoTop.setImageURI(uri);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivPhotoTop          = findViewById(R.id.ivPhotoTop);
        etImie              = findViewById(R.id.etImie);
        etNazwisko          = findViewById(R.id.etNazwisko);
        etEmail             = findViewById(R.id.etEmail);
        etTelefon           = findViewById(R.id.etTelefon);
        rgPlec              = findViewById(R.id.rgPlec);
        women               = findViewById(R.id.rbKobieta);
        men                 = findViewById(R.id.rbMezczyzna);
        cbZgoda             = findViewById(R.id.cbZgoda);
        switchOferty        = findViewById(R.id.switchOferty);
        switchZablokuj      = findViewById(R.id.switchZablokuj);
        spinnerWyksztalcenie = findViewById(R.id.spinnerWyksztalcenie);
        tvPodsumowanie      = findViewById(R.id.tvPodsumowanie);
    }

    public void wybierzZdjecie(View v) {
        launcher.launch("image/*");
    }

    public void zapisz(View v) {
        String imie     = etImie.getText().toString().trim();
        String nazwisko = etNazwisko.getText().toString().trim();
        String email    = etEmail.getText().toString().trim();
        String telefon  = etTelefon.getText().toString().trim();

        String plec = "Nie wybrano";
        int id = rgPlec.getCheckedRadioButtonId();
        if (id == R.id.rbKobieta) {
            plec = "Kobieta";
        } else if (id == R.id.rbMezczyzna) {
            plec = "Mężczyzna";
        }

        String wyksztalcenie = spinnerWyksztalcenie.getSelectedItem().toString();

        String zgoda  = cbZgoda.isChecked()   ? "Tak" : "Nie";
        String oferty = switchOferty.isChecked() ? "Tak" : "Nie";

        String tekst =
                "Imię: " + imie + "\n" +
                        "Nazwisko: " + nazwisko + "\n" +
                        "Email: " + email + "\n" +
                        "Telefon: " + telefon + "\n" +
                        "Płeć: " + plec + "\n" +
                        "Wykształcenie: " + wyksztalcenie + "\n" +
                        "Zgoda: " + zgoda + "\n" +
                        "Oferty pracy: " + oferty;

        tvPodsumowanie.setText(tekst);
        tvPodsumowanie.setVisibility(View.VISIBLE);
    }

    public void zablokujPola(View view) {
        SwitchCompat sw = (SwitchCompat) view;
        boolean blokuj = sw.isChecked();
        boolean stan = !blokuj;

        etImie.setEnabled(stan);
        etNazwisko.setEnabled(stan);
        etEmail.setEnabled(stan);
        etTelefon.setEnabled(stan);
        rgPlec.setEnabled(stan);
        women.setEnabled(stan);
        men.setEnabled(stan);
        cbZgoda.setEnabled(stan);
        switchOferty.setEnabled(stan);
        spinnerWyksztalcenie.setEnabled(stan);

        ivPhotoTop.setEnabled(stan);
        ivPhotoTop.setClickable(stan);
    }
}